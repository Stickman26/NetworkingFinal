HUB_ISTTS_0.1: Networked Platformer Prototype
Contributers:
Lansingh Freeman
Jason Gold

1) Open HUB_ISTTS_0.1.exe in Server Folder to open the server
2) Open HUB_ISTTS_0.1.exe in Game Folder to open game 
3) In game, enter a network address (if local 127.0.0.1, need portforward for others)
4) Enter a username
5) Hit connect
6) Repeat steps 2-5 up to 3 more times for max player count.
7) WASD movement, mouse look, space bar jump, tab for accessing chat, esc to exit chat.
7a) Through text chat, console commands can be activated.
8) navigate jumping puzzles to get to the blue exit portal
9) repeat step 8, prototype has one level.